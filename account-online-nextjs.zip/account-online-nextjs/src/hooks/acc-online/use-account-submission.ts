import { useState, useRef } from "react";
import { ResponseNID } from "@/models/open-acc-online/nid.response.model";
import { MaritalModel } from "@/models/static/marital/marital.response";
import { OccupationModel } from "@/models/static/occupation/occupation.response";
import { ReferenceModel } from "@/models/static/reference/reference.response";
import { LegalTypeModel } from "@/models/static/legal-type/legal-type.response";
import { BranchModel } from "@/models/branch/branch.response";
import { LocationSubmitData } from "@/models/open-acc-online/address/open-acc-address.request.model";
import { formatDate } from "@/constants/AppResource/format-date/format-dd-mm-yyyy";
import { createOpenAccountService } from "@/services/open-account/openAccount.service";
import { uploadDocument } from "@/services/document/document.service";
import { parseDate } from "@/utils/date-parser";

interface UseAccountSubmissionProps {
  formData: ResponseNID;
  uploadedImage: { idImage: string } | null;
  selfieImage: string | null;
  phoneNumber: string;
  selectedMaritalStatus: MaritalModel | null;
  selectedOccupation: OccupationModel | null;
  selectedReferenceBank: ReferenceModel | null;
  selectedLegalType: LegalTypeModel | null;
  selectedBranch: BranchModel | null;
  staffCode: string;
  locationData: LocationSubmitData;
  convertGenderToAPI: (gender: string) => string;
  getMaritalStatusString: (id: string) => string;
  translate: (key: string) => string;
}

interface LoadingState {
  isLoading: boolean;
  title: string;
  message: string;
}

interface UploadCache {
  nidFileName: string | null;
  selfieFileName: string | null;
}

const GENERIC_ERROR = {
  title: "មានបញ្ហាកើតឡើង",
  message:
    "មានបញ្ហាបច្ចេកទេស។ សូមពិនិត្យការតភ្ជាប់អ៊ីនធឺណិតរបស់អ្នក ហើយព្យាយាមម្តងទៀត។",
  variant: "error" as const,
};

export const useAccountSubmission = ({
  formData,
  uploadedImage,
  selfieImage,
  phoneNumber,
  selectedMaritalStatus,
  selectedOccupation,
  selectedReferenceBank,
  selectedLegalType,
  selectedBranch,
  staffCode,
  locationData,
  convertGenderToAPI,
  getMaritalStatusString,
  translate,
}: UseAccountSubmissionProps) => {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [successData, setSuccessData] = useState({
    title: "",
    message: "",
    status: "PENDING",
  });
  const [showSubmitErrorModal, setShowSubmitErrorModal] = useState(false);
  const [submitErrorData, setSubmitErrorData] = useState<{
    title: string;
    message: string;
    variant?: "error" | "warning";
  }>({
    title: "",
    message: "",
    variant: "error",
  });
  const [showAccountExistsModal, setShowAccountExistsModal] = useState(false);
  const [accountExistsData, setAccountExistsData] = useState<{
    cif?: string;
    accountNumber?: string;
    accountName?: string;
    message?: string;
  } | null>(null);
  const [loadingState, setLoadingState] = useState<LoadingState>({
    isLoading: false,
    title: "",
    message: "",
  });

  // ── Cache uploaded filenames to prevent duplicate uploads ──
  const uploadCache = useRef<UploadCache>({
    nidFileName: null,
    selfieFileName: null,
  });

  const showError = (override?: Partial<typeof GENERIC_ERROR>) => {
    setSubmitErrorData({ ...GENERIC_ERROR, ...override });
    setShowSubmitErrorModal(true);
  };

  // ── Call this when user retakes NID or Selfie photo ──
  const resetUploadCache = () => {
    uploadCache.current = { nidFileName: null, selfieFileName: null };
  };

  // ── Validate dates are not in the future ──
  const validateDates = (): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayFormatted = today.toISOString().split('T')[0];

    // Validate legal issue date (issuedDate from NID)
    if (formData.issuedDate) {
      const issuedDate = parseDate(formData.issuedDate);
      if (!issuedDate) {
        showError({
          title: "កាលបរិច្ឆេទមិនត្រឹមត្រូវ",
          message: `មិនអាចវិश្ញាសនកាលបរិច្ឆេទចេញលិខិត (${formData.issuedDate})។ ទម្រង់ត្រឹមត្រូវគឺ DD/MM/YYYY ឬ YYYY-MM-DD។`,
        });
        return false;
      }

      issuedDate.setHours(0, 0, 0, 0);
      if (issuedDate > today) {
        showError({
          title: "កាលបរិច្ឆេទមិនត្រឹមត្រូវ",
          message: `កាលបរិច្ឆេទចេញលិខិត (${formData.issuedDate}) មិនអាចជាកាលបរិច្ឆេទពេលអនាគតបានទេ។ សូមប្រើនឹង៖ ${todayFormatted} ឬលឿងជាង។`,
        });
        return false;
      }
    }

    // Validate date of birth
    if (formData.dob) {
      const dob = parseDate(formData.dob);
      if (!dob) {
        showError({
          title: "កាលបរិច្ឆេទមិនត្រឹមត្រូវ",
          message: `មិនអាចវិស្ញាសនកាលបរិច្ឆេទកំណើត (${formData.dob})។ ទម្រង់ត្រឹមត្រូវគឺ DD/MM/YYYY ឬ YYYY-MM-DD។`,
        });
        return false;
      }

      dob.setHours(0, 0, 0, 0);
      if (dob > today) {
        showError({
          title: "កាលបរិច្ឆេទមិនត្រឹមត្រូវ",
          message: `កាលបរិច្ឆេទកំណើត (${formData.dob}) មិនអាចជាកាលបរិច្ឆេទពេលអនាគតបានទេ។ សូមប្រើ៖ ${todayFormatted} ឬលឿងជាង។`,
        });
        return false;
      }
    }

    // Expiration date is allowed to be in future - no validation needed
    return true;
  };

  const handleSubmitAccount = async () => {
    // ── 1. Guard: validate dates are not in future ──
    if (!validateDates()) {
      return;
    }

    // ── 2. Guard: validate images exist ──
    const nidBase64Full: string = uploadedImage?.idImage ?? "";
    const selfieBase64Full: string = selfieImage ?? "";

    if (!nidBase64Full) {
      showError({
        title: "រូបភាព NID បាត់",
        message: "រូបភាព NID បាត់។ សូមថតរូបម្ដងទៀត រួចព្យាយាមម្ដងទៀត។",
      });
      return;
    }

    if (!selfieBase64Full) {
      showError({
        title: "រូបថតខ្លួនបាត់",
        message: "រូបថតខ្លួនបាត់។ សូមថតរូបម្ដងទៀត រួចព្យាយាមម្ដងទៀត។",
      });
      return;
    }

    setLoadingState({
      isLoading: true,
      title: "កំពុងដាក់ស្នើ",
      message: "កំពុងផ្ទុករូបភាព...",
    });

    try {
      // ── 3. Upload only if not already uploaded this session ──
      if (
        !uploadCache.current.nidFileName ||
        !uploadCache.current.selfieFileName
      ) {
        const [nidFileName, selfieFileName] = await Promise.all([
          uploadCache.current.nidFileName
            ? Promise.resolve(uploadCache.current.nidFileName)
            : uploadDocument(
                nidBase64Full,
                `nid_${formData.idNumber}.jpg`,
                "nid",
                formData.idNumber,
              ),
          uploadCache.current.selfieFileName
            ? Promise.resolve(uploadCache.current.selfieFileName)
            : uploadDocument(
                selfieBase64Full,
                `selfie_${formData.idNumber}.jpg`,
                "selfie",
                formData.idNumber,
              ),
        ]);

        // Store in cache — retry reuses these, no duplicate upload
        uploadCache.current = { nidFileName, selfieFileName };
      }

      const { nidFileName, selfieFileName } = uploadCache.current;

      // ── 4. Update loading message ──
      setLoadingState((prev) => ({
        ...prev,
        message: "កំពុងដាក់ស្នើសុំបង្កើតគណនីសម្រាប់ឆ្លើយប្រតិកម្ម...",
      }));

      // ── 5. Submit account ── Submit ALL available form data directly
      const accountData = {
        // NID Data - from form
        legalId: formData.idNumber,
        familyName: formData.lastNameEn,
        givenName: formData.firstNameEn,
        firstNameKh: formData.firstNameKh,
        lastNameKh: formData.lastNameKh,
        gender: convertGenderToAPI(formData.gender),
        dateOfBirth: formatDate(formData.dob),
        legalAddress: formData.address,
        placeOfBirth: formData.pob,
        legalIssueDate: formatDate(formData.issuedDate),
        legalExpireDate: formatDate(formData.expiredDate),
        legalMrz1: formData.MRZ1,
        legalMrz2: formData.MRZ2,
        legalMrz3: formData.MRZ3,

        // Legal Type Selection - use empty string if not selected
        legalDocType: selectedLegalType?.legalTypeValue || "",

        // Phone and Contact
        phoneNumber: phoneNumber,

        // Marital Status - use empty string if not selected
        maritalStatus: selectedMaritalStatus
          ? getMaritalStatusString(selectedMaritalStatus.id.toString())
          : "",

        // Occupation - use empty string if not selected
        occupation: selectedOccupation?.occupationCode || "",

        // Reference Bank - use empty string if not selected
        companyName: selectedReferenceBank?.nameEn || "",

        // Staff/Referral - use empty string if not provided
        referralId: staffCode || "",
        releasedBy: staffCode || "",

        // Branch - always required
        branchCode: selectedBranch!.branchID,

        // Current Address - use empty string if not selected
        customerCurrentProvince: locationData.currentAddress.province?.provinceCode || "",
        customerCurrentDistrict: locationData.currentAddress.district?.districtCode || "",
        customerCurrentCommune: locationData.currentAddress.commune?.communeCode || "",
        customerCurrentVillage: locationData.currentAddress.village?.villageCode || "",
        customerProvinceKh: locationData.currentAddress.province?.provinceKh || "",
        customerDistrictKh: locationData.currentAddress.district?.districtKh || "",
        customerCommuneKh: locationData.currentAddress.commune?.communeKh || "",
        customerVillageKh: locationData.currentAddress.village?.villageKh || "",

        // Place of Birth Address - use empty string if not selected
        customerPobProvince: locationData.placeOfBirth.province?.provinceCode || "",
        customerPobDistrict: locationData.placeOfBirth.district?.districtCode || "",
        customerPobCommune: locationData.placeOfBirth.commune?.communeCode || "",
        customerPobVillage: locationData.placeOfBirth.village?.villageCode || "",
        customerPobProvinceKh: locationData.placeOfBirth.province?.provinceKh || "",
        customerPobDistrictKh: locationData.placeOfBirth.district?.districtKh || "",
        customerPobCommuneKh: locationData.placeOfBirth.commune?.communeKh || "",
        customerPobVillageKh: locationData.placeOfBirth.village?.villageKh || "",

        // Images
        nidImageName: nidFileName!,
        selfieImageName: selfieFileName!,

        // Default values
        customerRole: "OWNER",
      };

      const response = await createOpenAccountService(accountData);

      // ── 6. Clear cache on success ──
      uploadCache.current = { nidFileName: null, selfieFileName: null };

      setSuccessData({
        title: "សូមរង់ចាំ",
        message: response?.message || "ស្នើសុំបង្កើតគណនីរបស់អ្នកត្រូវបានបញ្ជូនដោយជោគជ័យ។\n\nយើ្ងកំពុងដំណើរការស្នើសុំរបស់អ្នក ដែលរួមបញ្ចូល៖\n• ពិនិត្យលម្អិតព័ត៌មាន\n• ផ្ទៀងផ្ទាត់ឯកសារ\n• វាយតម្លៃហានិភัយ\n\nសូមរង់ចាំក្នុងរយៈពេល ១-៣ ថ្ងៃធ្វើការ។\n\nប្រសិនបើអ្នកមានសំណួរ សូមទាក់ទងយើ្ង៖\n📞 ទូរស័ព្ទ: ០៧ ២០០ ០០២ ឬ ១៨០០ ២០០ ៨៨៨\n🕐 ម៉ោងបើកលើ: ០៨:០០ - ១៨:០០ (ច័ន្ទ - សុក្រ)\n💬 អ៊ីមែល: support@cpbank.com",
        status: "PENDING",
      });
      setShowSuccessModal(true);
    } catch (error: any) {
      // Extract actual error message from backend
      const errorMessage = error?.errorMessage || error?.message;
      const errorResponse = error?.rawError;

      // Check if this is a pending request already exists message
      const isPendingRequest = errorMessage?.toLowerCase().includes("ដាក់ស្នើសុំបង្កើតគណនីរួចហើយ");

      // Check if account already exists (check for both English and Khmer keywords)
      // Includes: account exists, mobile banking already exists, etc.
      const isAccountExists =
        errorMessage?.toLowerCase().includes("exist") ||
        errorMessage?.toLowerCase().includes("already") ||
        errorMessage?.includes("រួចហើយ") ||
        errorMessage?.includes("គណនីមាន") ||
        errorMessage?.includes("មានគណនី") ||
        errorResponse?.message?.toLowerCase().includes("exist") ||
        errorResponse?.message?.toLowerCase().includes("already") ||
        errorResponse?.message?.includes("រួចហើយ") ||
        // Mobile banking specific
        errorMessage?.toLowerCase().includes("username") ||
        errorMessage?.toLowerCase().includes("mobile banking");

      if (isPendingRequest) {
        // Show success modal for pending request - use message from backend
        setSuccessData({
          title: "សូមរង់ចាំ",
          message: errorMessage,
          status: "PENDING",
        });
        setShowSuccessModal(true);
      } else if (isAccountExists) {
        // Show account exists modal with account details (if available)
        setAccountExistsData({
          cif: errorResponse?.data?.cif,
          accountNumber: errorResponse?.data?.accountNumber || errorResponse?.data?.khrAccount,
          accountName: errorResponse?.data?.accountName || errorResponse?.data?.legalHolderName,
          message: errorMessage || "គណនីធនាគារលក់ដ៏ងរបស់អ្នកបានបង្កើតរួចរាល់។ អ្នកអាចបង្ហាញលេខគណនីរបស់អ្នក ឬបន្តប្រើប្រាស់វា។",
        });
        setShowAccountExistsModal(true);
      } else if (errorMessage) {
        // Show actual backend error message
        showError({
          title: "មានបញ្ហាកើតឡើង",
          message: errorMessage,
        });
      } else {
        // Fallback to generic error only if no message available
        showError();
      }
    } finally {
      setLoadingState({ isLoading: false, title: "", message: "" });
    }
  };

  return {
    handleSubmitAccount,
    resetUploadCache,
    showSuccessModal,
    setShowSuccessModal,
    successData,
    setSuccessData,
    showSubmitErrorModal,
    setShowSubmitErrorModal,
    submitErrorData,
    setSubmitErrorData,
    showAccountExistsModal,
    setShowAccountExistsModal,
    accountExistsData,
    setAccountExistsData,
    loadingState,
    setLoadingState,
  };
};

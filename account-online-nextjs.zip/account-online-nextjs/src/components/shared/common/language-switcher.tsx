"use client";

import { locales, type Locale } from "@/i18n/request";
import { useTranslations } from "next-intl";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Languages, Check, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useClientLocale } from "@/context/provider/local-provider";
import { localeConfig } from "@/constants/AppResource/language/language";

interface LanguageSwitcherProps {
  variant?: "default" | "compact" | "flag-only";
  showBadge?: boolean;
  className?: string;
}

export default function LanguageSwitcher({
  variant = "default",
  showBadge = false,
  className,
}: LanguageSwitcherProps) {
  const { locale: currentLocale, setLocale, isLoading } = useClientLocale();
  const t = useTranslations("common");
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleLanguageChange = (newLocale: Locale) => {
    if (newLocale !== currentLocale && !isLoading) {
      setLocale(newLocale);
    }
  };

  // Don't render until client-side to avoid hydration mismatch
  if (!isClient) {
    return (
      <div
        className={cn("w-10 h-10 animate-pulse bg-muted rounded-md", className)}
      />
    );
  }

  const currentLocaleConfig =
    localeConfig[currentLocale as keyof typeof localeConfig];

  // Compact variant - just flag and code
  if (variant === "compact") {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className={cn("h-10 px-3 gap-2", className)}
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <span className="text-2xl">{currentLocaleConfig.flag}</span>
                <span className="text-sm font-semibold">
                  {currentLocaleConfig.code.toUpperCase()}
                </span>
              </>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          {locales.map((locale) => {
            const config = localeConfig[locale as keyof typeof localeConfig];
            const isSelected = locale === currentLocale;

            return (
              <DropdownMenuItem
                key={locale}
                onClick={() => handleLanguageChange(locale)}
                className={cn(
                  "flex items-center justify-between cursor-pointer",
                  isSelected && "bg-accent",
                  isLoading && "opacity-50"
                )}
                disabled={isLoading}
              >
                <div className="flex items-center gap-2">
                  <span>{config.flag}</span>
                  <span className="font-medium">{config.nativeName}</span>
                </div>
                {isSelected && <Check className="h-4 w-4" />}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  // Flag only variant
  if (variant === "flag-only") {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className={cn("h-10 px-3 gap-2", className)}
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <img
                  src={currentLocaleConfig.flag}
                  alt={`${currentLocaleConfig.nativeName} flag`}
                  className="w-7 h-5 object-cover rounded-sm"
                />
                <span className="text-sm font-semibold">
                  {currentLocaleConfig.code.toUpperCase()}
                </span>
              </>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          {locales.map((locale) => {
            const config = localeConfig[locale as keyof typeof localeConfig];
            const isSelected = locale === currentLocale;

            return (
              <DropdownMenuItem
                key={locale}
                onClick={() => handleLanguageChange(locale)}
                className={cn(
                  "flex items-center justify-between cursor-pointer",
                  isSelected && "bg-accent",
                  isLoading && "opacity-50"
                )}
                disabled={isLoading}
              >
                <div className="flex items-center gap-2">
                  <img
                    src={config.flag}
                    alt={`${config.nativeName} flag`}
                    className="w-5 h-4 object-cover rounded-sm"
                  />
                  <span className="font-medium">{config.nativeName}</span>
                </div>
                {isSelected && <Check className="h-4 w-4" />}
                {isLoading && locale === currentLocale && (
                  <Loader2 className="h-3 w-3 animate-spin" />
                )}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  // Default variant - full featured
  return (
    <div className={cn("flex items-center gap-2", className)}>
      {showBadge && (
        <Badge variant="secondary" className="text-xs">
          {t("language")}
        </Badge>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className="h-10 px-3 gap-2"
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <>
                <span className="text-2xl">{currentLocaleConfig.flag}</span>
                <span className="font-semibold">
                  {currentLocaleConfig.code.toUpperCase()}
                </span>
              </>
            )}
          </Button>
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end" className="w-56">
          <div className="px-2 py-1.5">
            <p className="text-sm font-medium text-muted-foreground">
              {t("selectLanguage")}
            </p>
          </div>

          {locales.map((locale) => {
            const config = localeConfig[locale as keyof typeof localeConfig];
            const isSelected = locale === currentLocale;

            return (
              <DropdownMenuItem
                key={locale}
                onClick={() => handleLanguageChange(locale)}
                className={cn(
                  "flex items-center justify-between cursor-pointer py-2",
                  isSelected && "bg-accent",
                  isLoading && "opacity-50"
                )}
                disabled={isLoading}
              >
                <div className="flex items-center gap-3">
                  <span className="text-lg">{config.flag}</span>
                  <div className="flex flex-col">
                    <span className="font-medium">{config.nativeName}</span>
                    <span className="text-xs text-muted-foreground">
                      {config.name}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {isSelected && <Check className="h-4 w-4 text-primary" />}
                  {isLoading && locale === currentLocale && (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  )}
                </div>
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

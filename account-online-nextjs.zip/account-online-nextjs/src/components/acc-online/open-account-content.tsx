"use client";
// UI Components
import { Button } from "@/components/ui/button";
import Footer from "@/components/shared/footer/footer";
// Feature Components
import { AccountImages } from "@/components/acc-online/account-images";
import { PersonalDetailsFields } from "@/components/acc-online/form-sections/personal-details-fields";
import { MasterDataFields } from "@/components/acc-online/form-sections/master-data-fields";
import OTPInput from "@/components/acc-online/form-field/form-otp";
import { PageHeader } from "@/components/acc-online/page-header";
import ValidationErrorModal from "@/components/acc-online/validateModal";
import ErrorModal from "@/components/acc-online/errorModal";
import ConfirmationModal from "@/components/acc-online/confirmModal";
import LocationModal from "@/components/acc-online/addressModal";
import AccountExistsModal from "@/components/acc-online/accountExistsModal";
import LoadingModal from "@/components/shared/modal/extract-modal";
import SubmitSuccessModal from "@/components/shared/modal/submit-success-modal";
import SubmitErrorModal from "@/components/shared/modal/submit-error-modal";
import { HeaderSection } from "@/components/acc-online/header-section";
import { ConfirmClearModal } from "@/components/acc-online/confirm-clear-modal";
// Contexts
import { FormStateProvider } from "@/contexts/form-state-context";
// Hooks
import { useMemo, useCallback, useState } from "react";
import { useAccountImages } from "@/hooks/acc-online/use-account-images";
import { useAccountOtp } from "@/hooks/acc-online/use-account-otp";
import { useMasterData } from "@/hooks/acc-online/use-master-data";
import { useFormValidation } from "@/hooks/acc-online/use-form-validation";
import { useModalState } from "@/hooks/acc-online/use-modal-state";
import { useAccountSubmission } from "@/hooks/acc-online/use-account-submission";
import { useVerificationFlow } from "@/hooks/acc-online/use-verification-flow";
// Types
import { LocationSubmitData } from "@/models/open-acc-online/address/open-acc-address.request.model";

const SectionLabel = ({ label }: { label: string }) => (
  <div className="flex items-center gap-2 mb-5">
    <div className="w-1 h-4 rounded-full bg-primary flex-shrink-0" />
    <p className="text-sm font-semibold uppercase tracking-wider text-gray-400">{label}</p>
  </div>
);

const Divider = () => <div className="border-t border-gray-100 mx-4 sm:mx-6 lg:mx-8" />;

interface OpenAccountContentProps {
  // true for the public self-service ("/") flow: hides category selection,
  // forces category 6011, and does not require a relation manager.
  isPublic?: boolean;
}

export function OpenAccountContent({ isPublic = false }: OpenAccountContentProps) {
  // ========================================
  // Hooks Setup
  // ========================================
  const {
    formData,
    setFormData,
    validationErrors,
    setValidationErrors,
    datePickerKey,
    validateField,
    handleValidationChange,
    handleInputChange,
    clearValidation,
    translate,
    translateSelect,
  } = useFormValidation(isPublic);

  const {
    showLocationModal,
    setShowLocationModal,
    showErrorModal,
    setShowErrorModal,
    validationResult,
    setValidationResult,
    showValidationErrorModal,
    setShowValidationErrorModal,
    validationErrorData,
    setValidationErrorData,
    showConfirmationModal,
    setShowConfirmationModal,
    locationData,
    setLocationData,
    locationFormData,
    setLocationFormData,
    clearModalState,
  } = useModalState();

  const {
    maritalStatuses,
    isLoadingMarital,
    selectedMaritalStatus,
    setSelectedMaritalStatus,
    occupations,
    isLoadingOccupations,
    selectedOccupation,
    setSelectedOccupation,
    referenceBanks,
    isLoadingReferenceBanks,
    selectedReferenceBank,
    setSelectedReferenceBank,
    legalTypes,
    isLegalTypeLoading,
    selectedLegalType,
    setSelectedLegalType,
    accOnlineCategories,
    isLoadingCategories,
    selectedCategory,
    setSelectedCategory,
    getMaritalName,
    getOccupationName,
    getReferenceName,
    getLegalTypeName,
    getMaritalStatusString,
    resetMasterData,
  } = useMasterData();

  const {
    phoneNumber,
    setPhoneNumber,
    isPhoneVerified,
    setIsPhoneVerified,
    resetOtp,
    clearOtp,
  } = useAccountOtp();

  const {
    uploadedImage,
    selfiePreview,
    selfieImage,
    handleImageUpload,
    handleSelfieUpload,
    loadingImageState,
    clearImages,
    ocrErrorData,
    clearOcrError,
  } = useAccountImages({
    setFormData,
    validateField,
    translate,
  });

  const {
    isLoading,
    isValidating,
    selectedBranch,
    setSelectedBranch,
    staffCode,
    setStaffCode,
    isVerified,
    setIsVerified,
    convertGenderToAPI,
    handleValidateNID,
    handleOpenConfirmModal,
    handleLocationSubmit,
    onBranchChange,
  } = useVerificationFlow({
    formData,
    setFormData,
    validationErrors,
    setValidationErrors,
    validateField,
    selectedMaritalStatus,
    selectedOccupation,
    selectedReferenceBank,
    selectedLegalType,
    selectedCategory,
    phoneNumber,
    isPublic,
  });

  const {
    handleSubmitAccount,
    showSuccessModal,
    setShowSuccessModal,
    successData,
    showSubmitErrorModal,
    setShowSubmitErrorModal,
    submitErrorData,
    showAccountExistsModal,
    setShowAccountExistsModal,
    accountExistsData,
    loadingState,
  } = useAccountSubmission({
    formData,
    uploadedImage,
    selfieImage,
    phoneNumber,
    selectedMaritalStatus,
    selectedOccupation,
    selectedReferenceBank,
    selectedLegalType,
    selectedBranch,
    selectedCategory,
    staffCode,
    locationData,
    convertGenderToAPI,
    getMaritalStatusString,
    translate,
    isPublic,
  });

  // ========================================
  // Additional State for Clear Confirmation
  // ========================================
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Combine all busy states into one flag to disable buttons consistently.
  // Includes isLoadingCategories so Verify/Submit can't race ahead of the
  // 6011-default auto-select effect and falsely fail "accountProduct" validation.
  const isBusy = isLoading || isValidating || loadingState.isLoading || isLoadingCategories;

  // ========================================
  // Event Handlers
  // ========================================
  const handleConfirmValidation = useCallback(async () => {
    setShowConfirmationModal(false);
    await handleValidateNID(
      setShowLocationModal,
      setShowErrorModal,
      setValidationResult,
      setShowValidationErrorModal,
      setValidationErrorData,
    );
  }, [
    handleValidateNID,
    setShowConfirmationModal,
    setShowLocationModal,
    setShowErrorModal,
    setValidationResult,
    setShowValidationErrorModal,
    setValidationErrorData,
  ]);

  const handleLocationSubmitCallback = useCallback(
    (data: LocationSubmitData) => {
      handleLocationSubmit(data, setLocationData, setShowLocationModal);
    },
    [handleLocationSubmit, setLocationData, setShowLocationModal],
  );

  const handleVerificationClick = useCallback(() => {
    handleOpenConfirmModal(
      uploadedImage?.idImage || "",
      selfieImage || "",
      phoneNumber,
      isPhoneVerified,
      setShowConfirmationModal,
    );
  }, [
    handleOpenConfirmModal,
    uploadedImage,
    selfieImage,
    phoneNumber,
    isPhoneVerified,
    setShowConfirmationModal,
  ]);

  const handlePhoneChange = useCallback(
    (value: string) => {
      setPhoneNumber(value);
      validateField("phoneNumber", value);
      setIsVerified(false);
    },
    [setPhoneNumber, validateField, setIsVerified],
  );

  const handleVerificationSuccess = useCallback(() => {
    setIsPhoneVerified(true);
    validateField("isPhoneVerified", true);
  }, [setIsPhoneVerified, validateField]);

  const handleClear = useCallback(() => {
    clearValidation();
    clearImages();
    clearOtp();
    clearModalState();
    resetMasterData();
    setSelectedBranch(null);
    setStaffCode("");
    setIsVerified(false);
    setShowClearConfirm(false);
  }, [
    clearValidation,
    clearImages,
    clearOtp,
    clearModalState,
    resetMasterData,
    setSelectedBranch,
    setStaffCode,
    setIsVerified,
    setShowClearConfirm,
  ]);

  const handleInputChangeWrapper = useCallback(
    (field: any, value: string) => {
      handleInputChange(field, value);
      setIsVerified(false);
    },
    [handleInputChange, setIsVerified],
  );

  const handleMasterDataChange = useCallback(
    (setter: any, value: any) => {
      setter(value);
      setIsVerified(false);
    },
    [setIsVerified],
  );

  const handleSuccessModalClose = useCallback(() => {
    setShowSuccessModal(false);
    handleClear();
  }, [setShowSuccessModal, handleClear]);

  const handleSetSelectedLegalType = useCallback(
    (val: any) => handleMasterDataChange(setSelectedLegalType, val),
    [handleMasterDataChange, setSelectedLegalType],
  );

  const handleSetSelectedMaritalStatus = useCallback(
    (val: any) => handleMasterDataChange(setSelectedMaritalStatus, val),
    [handleMasterDataChange, setSelectedMaritalStatus],
  );

  const handleSetSelectedOccupation = useCallback(
    (val: any) => handleMasterDataChange(setSelectedOccupation, val),
    [handleMasterDataChange, setSelectedOccupation],
  );

  const handleSetSelectedReferenceBank = useCallback(
    (val: any) => handleMasterDataChange(setSelectedReferenceBank, val),
    [handleMasterDataChange, setSelectedReferenceBank],
  );

  const handleSetStaffCode = useCallback(
    (val: any) => handleMasterDataChange(setStaffCode, val),
    [handleMasterDataChange, setStaffCode],
  );

  const handleBranchChange = useCallback(
    (val: any) => { onBranchChange(val); setIsVerified(false); },
    [onBranchChange, setIsVerified],
  );

  // ========================================
  // Context Setup
  // ========================================
  const formStateContextValue = useMemo(
    () => ({
      isLoading,
      isValidating,
      isSubmitting: loadingState.isLoading, // FIX: expose submission loading to context
      translate,
      translateSelect,
      validationErrors,
      validateField,
      handleValidationChange,
    }),
    [
      isLoading,
      isValidating,
      loadingState.isLoading,
      translate,
      translateSelect,
      validationErrors,
      validateField,
      handleValidationChange,
    ],
  );

  // ========================================
  // Render
  // ========================================
  return (
    <FormStateProvider value={formStateContextValue}>
      <div className="min-h-screen flex flex-col bg-gray-50/60">
        <PageHeader />

        <main className="flex-1 pt-16 sm:pt-[60px]">
          <div className="max-w-7xl mx-auto w-full px-3 sm:px-5 lg:px-8 py-4 sm:py-6 lg:py-8">

            {/* Page title */}
            <HeaderSection
              title={translate("header_acc")}
              onClear={() => setShowClearConfirm(true)}
              translate={translate}
            />

            {/* Single form card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100">

              {/* ── Document Upload ── */}
              <div className="p-4 sm:p-5 lg:p-6">
                <SectionLabel label={translate("section_document_upload")} />
                <AccountImages
                  uploadedImage={uploadedImage}
                  selfiePreview={selfiePreview}
                  handleImageUpload={handleImageUpload}
                  handleSelfieUpload={handleSelfieUpload}
                />
              </div>

              <Divider />

              {/* ── Personal Details + Additional Information ── */}
              <div className="p-4 sm:p-6 lg:p-8">
                <SectionLabel label={translate("section_personal_details")} />
                <PersonalDetailsFields
                  formData={formData}
                  handleInputChange={handleInputChangeWrapper}
                  datePickerKey={datePickerKey}
                  legalTypes={legalTypes}
                  selectedLegalType={selectedLegalType}
                  setSelectedLegalType={handleSetSelectedLegalType}
                  isLegalTypeLoading={isLegalTypeLoading}
                  getLegalTypeName={getLegalTypeName}
                  isVerified={isVerified}
                  isNidExtracted={!!uploadedImage}
                />
                <MasterDataFields
                  maritalStatuses={maritalStatuses}
                  selectedMaritalStatus={selectedMaritalStatus}
                  setSelectedMaritalStatus={handleSetSelectedMaritalStatus}
                  isLoadingMarital={isLoadingMarital}
                  getMaritalName={getMaritalName}
                  occupations={occupations}
                  selectedOccupation={selectedOccupation}
                  setSelectedOccupation={handleSetSelectedOccupation}
                  isLoadingOccupations={isLoadingOccupations}
                  getOccupationName={getOccupationName}
                  selectedBranch={selectedBranch}
                  onBranchChange={handleBranchChange}
                  staffCode={staffCode}
                  setStaffCode={handleSetStaffCode}
                  accOnlineCategories={accOnlineCategories}
                  selectedCategory={selectedCategory}
                  setSelectedCategory={setSelectedCategory}
                  isLoadingCategories={isLoadingCategories}
                  isVerified={isVerified}
                  isPublic={isPublic}
                />
              </div>

              <Divider />

              {/* ── Phone Verification ── */}
              <div className="p-4 sm:p-6 lg:p-8">
                <SectionLabel label={translate("section_phone_verification")} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                  <OTPInput
                    phoneNumber={phoneNumber}
                    onPhoneChange={handlePhoneChange}
                    onVerificationSuccess={handleVerificationSuccess}
                    disabled={isBusy}
                    validationErrors={validationErrors}
                    onValidationChange={handleValidationChange}
                    reset={resetOtp}
                  />
                </div>
              </div>

              {/* ── Action buttons inside the card (flows with page, never fixed) ── */}
              <div className="px-4 sm:px-6 lg:px-8 py-4 sm:py-5 border-t border-gray-100 bg-gray-50/50 rounded-b-2xl">
                <div className="flex flex-col sm:flex-row sm:justify-end gap-3">
                  <Button
                    className="w-full sm:w-auto sm:min-w-[160px] h-auto min-h-12 py-3 font-semibold rounded-xl text-base sm:text-sm flex items-center justify-center gap-2 transition-all
                      border-2 border-primary text-primary bg-white hover:bg-primary/5 active:bg-primary/10
                      disabled:opacity-40 disabled:cursor-not-allowed"
                    onClick={handleVerificationClick}
                    disabled={isBusy || isVerified}
                    variant="outline"
                  >
                    {isValidating ? (
                      <><span className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin flex-shrink-0" /><span className="whitespace-normal leading-tight text-center">{translate("processing")}</span></>
                    ) : <span className="whitespace-normal leading-tight text-center">{translate("verification")}</span>}
                  </Button>
                  <Button
                    className="w-full sm:w-auto sm:min-w-[160px] h-auto min-h-12 py-3 font-semibold rounded-xl text-base sm:text-sm flex items-center justify-center gap-2 transition-all
                      bg-primary hover:bg-primary/90 active:bg-primary/90 text-primary-foreground shadow-sm
                      disabled:opacity-40 disabled:cursor-not-allowed"
                    onClick={handleSubmitAccount}
                    disabled={isBusy || !isVerified}
                  >
                    {loadingState.isLoading ? (
                      <><span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin flex-shrink-0" /><span className="whitespace-normal leading-tight text-center">{translate("submitting") || "Submitting"}</span></>
                    ) : <span className="whitespace-normal leading-tight text-center">{translate("submit")}</span>}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          <Footer />
        </main>

        {/* Clear Confirmation Modal */}
        <ConfirmClearModal
          isOpen={showClearConfirm}
          onClose={() => setShowClearConfirm(false)}
          onConfirm={handleClear}
          title={translate("clearTitle")}
          message={translate("clearConfirmMessage")}
        />

        {/* Submission loading */}
        <LoadingModal
          isOpen={loadingState.isLoading}
          title={loadingState.title}
          message={loadingState.message}
        />

        {/* Image extraction loading */}
        <LoadingModal
          isOpen={loadingImageState.isLoading}
          title={loadingImageState.title}
          message={loadingImageState.message}
        />

        <ConfirmationModal
          isOpen={showConfirmationModal}
          onConfirm={handleConfirmValidation}
          onCancel={() => setShowConfirmationModal(false)}
          title={translate("cfTitle")}
          message={translate("cfMessage")}
        />
        <LocationModal
          isOpen={showLocationModal}
          onClose={() => setShowLocationModal(false)}
          onSubmit={handleLocationSubmitCallback}
          formData={locationFormData}
          setFormData={setLocationFormData}
          addressFromForm={formData.address}
          placeOfBirthFromForm={formData.pob}
        />
        <ErrorModal
          isOpen={showErrorModal}
          onClose={() => setShowErrorModal(false)}
          data={
            validationResult?.data
              ? {
                  score: validationResult.data.score,
                  incorrectFields: validationResult.data.incorrectFields,
                }
              : null
          }
        />
        <ValidationErrorModal
          isOpen={showValidationErrorModal}
          onClose={() => setShowValidationErrorModal(false)}
          title={validationErrorData.title}
          message={validationErrorData.message}
          description={validationErrorData.description}
        />
        {/* OCR Extraction Error Modal */}
        <ValidationErrorModal
          isOpen={!!ocrErrorData}
          onClose={clearOcrError}
          title={ocrErrorData?.title ?? ""}
          message={ocrErrorData?.message ?? ""}
          description={ocrErrorData?.description ?? ""}
        />
        <SubmitSuccessModal
          isOpen={showSuccessModal}
          onClose={handleSuccessModalClose}
          data={successData}
        />
        <SubmitErrorModal
          isOpen={showSubmitErrorModal}
          onClose={() => setShowSubmitErrorModal(false)}
          title={submitErrorData.title}
          message={submitErrorData.message}
          variant={submitErrorData.variant}
        />
        <AccountExistsModal
          isOpen={showAccountExistsModal}
          onClose={() => setShowAccountExistsModal(false)}
          data={accountExistsData}
        />
      </div>
    </FormStateProvider>
  );
}

"use client";

import { Suspense } from "react";
import ConfirmDialog from "@/components/shared/dialog/dialog-confirm";
import { DeleteConfirmationDialog } from "@/components/shared/dialog/dialog-delete";
import ResetPasswordModal from "@/components/shared/dialog/dialog-reset-password";
import { CustomPagination } from "@/components/shared/pagination/custom-pagination";
import { DataTable } from "@/components/shared/table/data-table";
import { createUserTableColumns } from "@/features/user/table/table-content";
import { AppToast } from "@/components/shared/toast/app-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { ROUTES } from "@/constants/AppRoutes/routes";
import { usePagination } from "@/hooks/use-pagination";
import { AllUserModel, UserModel } from "@/features/user/types/user.response";
import {
  createUserService,
  deleteUserService,
  getUsersService,
  updateUserService,
} from "@/features/user/services/user.service";
import { useDebounce } from "@/utils/debounce/debounce";

import { PageHeader } from "@/components/shared/common/page-header";
import { TableToolbar } from "@/components/shared/common/table-toolbar";
import { Search, Users } from "lucide-react";
import { useTranslations } from "next-intl";
import { useSearchParams } from "next/navigation";
import { startTransition, useCallback, useEffect, useState } from "react";
import ModalUser from "@/features/user/components/user-modal";
import { CreateUserReq, UpdateUserReq } from "@/features/user/types/user.request";
import Loading from "@/components/shared/common/loading";
import { UserViewModal } from "@/features/user/components/user-detail-modal";
import { ModalMode } from "@/constants/AppResource/display-list/enum/mode";
import { getUserInfo } from "@/utils/local-storage/userInfo";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ROLE_FILTER_WITH_ALL } from "@/constants/AppResource/filter/role";

function UserPageContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [users, setUsers] = useState<AllUserModel | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusFilter, setStatusFilter] = useState("ACTIVE");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [selectedUser, setSelectedUser] = useState<UserModel | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [mode, setMode] = useState<ModalMode>(ModalMode.CREATE_MODE);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isUserDetailOpen, setIsUserDetailOpen] = useState(false);
  const [isResetPasswordDialogOpen, setIsResetPasswordDialogOpen] =
    useState(false);
  const [selectedUserToggle, setSelectedUserToggle] =
    useState<UserModel | null>(null);
  const [isToggleStatusDialogOpen, setIsToggleStatusDialogOpen] =
    useState(false);
  const [currentUser, setCurrentUser] = useState<UserModel | null>(null);

  const t = useTranslations();

  // Debounced search query - Optimized api performance when search
  const debouncedSearchQuery = useDebounce(searchQuery, 400);

  const { currentPage, handlePageChange } = usePagination({
    baseRoute: ROUTES.DASHBOARD.USER,
  });

  // Get current user info for take permission delete user
  useEffect(() => {
    const userInfo = getUserInfo();
    if (userInfo) {
      setCurrentUser(userInfo);
    }
  }, []);



  const loadUsers = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await getUsersService({
        search: debouncedSearchQuery,
        pageNo: currentPage,
        pageSize: 15,
        status: statusFilter,
        role: roleFilter === "ALL" ? undefined : roleFilter,
      });
      setUsers(response);
    } catch (error: any) {
      console.log("Failed to fetch users: ", error);
    } finally {
      setIsLoading(false);
    }
  }, [debouncedSearchQuery, statusFilter, roleFilter, currentPage]);

  useEffect(() => {
    loadUsers();
  }, [loadUsers, debouncedSearchQuery, statusFilter, roleFilter]);

  // Simplified search change handler - just updates the state, debouncing handles the rest
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const handleStatusToggle = async (user: UserModel | null) => {
    if (!user?.id) return;
    setIsLoading(true);
    try {
      const newStatus =
        user.userStatus.toUpperCase() === "ACTIVE" ? "DELETE" : "ACTIVE";

      // Optimistic update
      setUsers((prev) => {
        if (!prev) return null;
        const updatedContent = prev.content.map((item) =>
          item.id === user.id ? { ...item, status: newStatus } : item
        );
        return { ...prev, content: updatedContent };
      });

      await updateUserService(user.id, {
        status: newStatus,
      });

      AppToast({
        type: "success",
        message: "User status updated successfully",
      });
      setSelectedUserToggle(null);
      setIsToggleStatusDialogOpen(false);
    } catch (error: any) {
      AppToast({
        type: "error",
        message: "An error occurred while updating user status",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveUser = async (
    formData: CreateUserReq | { id: number; updates: UpdateUserReq }
  ) => {
    setIsSubmitting(true);
    try {
      if (mode === ModalMode.CREATE_MODE) {
        const createData = formData as CreateUserReq;

        const response = await createUserService({
          email: createData.email,
          fullName: createData.fullName,
          password: createData.password,
          role: createData.role,
          username: createData.username,
          position: createData.position,
          phoneNumber: createData.phoneNumber,
          branch: createData.branch,
          department: createData.department,
        });

        // Optimistic update
        setUsers((prev: any) =>
          prev
            ? {
                ...prev,
                content: [response, ...prev.content],
                totalElements: prev.totalElements + 1,
              }
            : {
                content: [response],
                pageNo: 1,
                pageSize: 10,
                totalElements: 1,
                totalPages: 1,
                hasNext: false,
                hasPrevious: false,
                first: true,
                last: true,
              }
        );

        startTransition(() => {
          AppToast({
            type: "success",
            message: "User created successfully",
            description: "New User",
          });
        });
      } else if (mode === ModalMode.UPDATE_MODE) {
        const updateData = formData as { id: number; updates: UpdateUserReq };

        if (!updateData.id) {
          console.error("Missing user id in update form");
          setIsSubmitting(false);
          return;
        }

        const response = await updateUserService(
          updateData.id,
          updateData.updates
        );

        setUsers((prev) =>
          prev
            ? {
                ...prev,
                content: prev.content.map((user) =>
                  user.id === updateData.id ? response : user
                ),
              }
            : prev
        );

        startTransition(() => {
          AppToast({
            type: "success",
            message: "User updated successfully",
            description: "Updated User",
          });
        });
      }

      setIsModalOpen(false);
      setSelectedUser(null);
      loadUsers();
    } catch (err: any) {
      AppToast({
        type: "error",
        message: "Failed to save user",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const confirmDeleteUser = async () => {
    if (!selectedUser) return;
    setIsSubmitting(true);
    try {
      await deleteUserService(selectedUser.id);
      AppToast({
        type: "success",
        message: "User deleted successfully",
      });
      setIsDeleteDialogOpen(false);
      setSelectedUser(null);
      loadUsers();
    } catch (err: any) {
      AppToast({
        type: "error",
        message: "Failed to delete user",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle status filter change - directly updates the filter value
  const handleStatusChange = (status: string) => {
    setStatusFilter(status);
  };

  const handleEditUser = (user: UserModel) => {
    setSelectedUser(user);
    setMode(ModalMode.UPDATE_MODE);
    setIsModalOpen(true);
  };

  const handleAddUser = () => {
    setSelectedUser(null);
    setMode(ModalMode.CREATE_MODE);
    setIsModalOpen(true);
  };

  const handleViewUserDetail = (user: UserModel) => {
    setSelectedUser(user);
    setIsUserDetailOpen(true);
  };

  const handleDeleteUser = (user: UserModel) => {
    setSelectedUser(user);
    setIsDeleteDialogOpen(true);
  };

  const handleResetPassword = (user: UserModel) => {
    setSelectedUser(user);
    setIsResetPasswordDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Users"
        subtitle="Manage back-office users and permissions"
        icon={Users}
        count={users?.totalElements || 0}
      />
      <Card className="h-full flex flex-col">
        <CardContent className="space-y-6 p-6 flex flex-col h-full">
          <TableToolbar
            searchQuery={searchQuery}
            onSearchChange={handleSearchChange}
            searchPlaceholder="Search users..."
            searchAriaLabel="search-user"
            disabled={isSubmitting}
            leftFilters={
              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger className="h-9 w-[160px] text-xs">
                  <SelectValue placeholder="All Roles" />
                </SelectTrigger>
                <SelectContent>
                  {ROLE_FILTER_WITH_ALL.map((r) => (
                    <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            }
            actions={<Button size="sm" onClick={handleAddUser}>New</Button>}
          />

        <div className="w-full">
          <Separator className="bg-gray-300" />
        </div>

        <div className="flex-1 flex flex-col min-h-0">
          {/* Table container with proper overflow handling */}
          <div className="flex-1 rounded-md border overflow-hidden flex flex-col">
            <div className="flex-1 overflow-x-auto">
              <DataTable
                data={users?.content || []}
                columns={createUserTableColumns({
                  data: users,
                  handlers: {
                    handleEditUser,
                    handleResetPassword,
                    handleViewUserDetail,
                    handleDeleteUser,
                  },
                  currentUser,
                })}
                loading={isLoading}
                emptyMessage="No user found"
                getRowKey={(user) => user.id}
              />
              {/* Pagination positioned to the right and outside the scrollable area */}
              <div className="border-t bg-background p-2 flex justify-end">
                <CustomPagination
                  currentPage={currentPage}
                  totalPages={users?.totalPages || 1}
                  onPageChange={handlePageChange}
                  size="md"
                />
              </div>
            </div>
          </div>
        </div>

        <DeleteConfirmationDialog
          isOpen={isDeleteDialogOpen}
          onClose={() => {
            setIsDeleteDialogOpen(false);
            setSelectedUser(null);
          }}
          onDelete={confirmDeleteUser}
          title="Delete Admin"
          description={`Are you sure you want to delete the admin`}
          itemName={selectedUser?.fullName || selectedUser?.email}
          isSubmitting={isSubmitting}
        />

        <ResetPasswordModal
          isOpen={isResetPasswordDialogOpen}
          userName={selectedUser?.fullName || selectedUser?.email}
          onClose={() => {
            setIsResetPasswordDialogOpen(false);
            setSelectedUser(null);
          }}
          userId={selectedUser?.id ?? 0}
        />

        <UserViewModal
          isOpen={isUserDetailOpen}
          onClose={() => {
            setIsUserDetailOpen(false);
            setSelectedUser(null);
          }}
          user={selectedUser ?? undefined}
        />

        <ModalUser
          isOpen={isModalOpen}
          mode={mode}
          onClose={() => {
            setSelectedUser(null);
            setIsModalOpen(false);
          }}
          onSave={handleSaveUser}
          userId={selectedUser?.id ?? 0}
          isSubmitting={isSubmitting}
        />

        {/* Confirm Dialog */}
        <ConfirmDialog
          isOpen={isToggleStatusDialogOpen}
          onClose={() => {
            setIsToggleStatusDialogOpen(false);
            setSelectedUserToggle(null);
          }}
          title="Change user status"
          description={`Are you sure you want to ${
            selectedUserToggle?.userStatus === "ACTIVE" ? "disable" : "enable"
          } this user: ${selectedUserToggle?.fullName}?`}
          cancelLabel="Cancel"
          onConfirm={() => handleStatusToggle(selectedUserToggle)}
          variant="warning"
          size="md"
        />
      </CardContent>
    </Card>
    </div>
  );
}

export default function UserPage() {
  return (
    <Suspense fallback={<Loading />}>
      <UserPageContent />
    </Suspense>
  );
}



